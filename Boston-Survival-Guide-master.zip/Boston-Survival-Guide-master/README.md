# Boston-Survival-Guide
This is a project focuses on Boston Crimes.

The main purpose of our project is to analyze patterns of crimes, the potential incentives for crimes, as well as how other factors such as housing prices, population, income correlate with crimes.

Hope our project will help you survive in Boston!!!

https://prezi.com/p/glemvd6cu2s8/boston-crimes/
